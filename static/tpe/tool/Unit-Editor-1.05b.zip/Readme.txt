
***********
General Use
***********

Note:
Always make a backup of ANY .XCR file you modify.


--Editing Units within an .XCR File (eg PatchData.xcr)--

1) Open WBC 3 Unit Editor, and click Load XCR.
2) Select the desired Unit from the file listing.
3) Make the desired changes to any units (The Editor will save your changes, but not to the file).
4) Once your are happy with your changes click Save XCR.


--Importing .ARM File into .XCR--

1) Open WBC 3 Unit Editor, and load the required XCR.
2) Click Open/Import and choose the .ARM file you want to import.  Note: .ARM file MUST be encrypted.
3) If required make changes to Unit, by selecting it from the file list.  Your new file will be the current selection.
4) If happy with your changes, click Save XCR.


--Deleting .ARM File from .XCR--

1) Open WBC 3 Unit Editor, and load the required XCR.
2) Select the file you wish to delete in the File listing, and press "Delete"



--Exporting .ARM File from .XCR--

1) Open WBC 3 Unit Editor, and load the required XCR.
2) Click Save/Export and choose a location and name to export the file too.  Note: .ARM will be exported as encrypted.


--Editing an Exported .ARM--

Note: 
.ARM files MUST be in ENCRYPTED state.  When using an XCR Editor, make sure you extract the file in its encrypted form.
WBC 3 Unit Editor always exports files in the Encrypted state.

1) Open WBC 3 Unit Editor, and click Open/Import.
2) Select the desired file.
3) Make desired changes.
4) Click Save.
5) To import modified .ARM into a .XCR file see "Importing .ARM File into .XCR" above.


--Why can't I edit the race of the unit etc?--

Quite a few features of Units are not stored within the .ARM files themselves but rather inside Army.cfg which resides
within the \Assets\Data\System.xcr file of your WBC 3 Installation.  I doubt I'll add the ability to modify this file unless
the game is changed so as it can load a modified version from within PatchData.xcr.

For more information on this go to the following URL:
http://www.the-battlefield.com/forum/index.php?showtopic=1250



**********
Change Log
**********

1.05b - 

Hopefully fixed XCR file corruption when loading a new XCR without closing/saving the old in the unit editor.
Unit names should now be more accurate (read from Army.cfg rather than XCR entry).
Included the updated Data.txt that Kharn changed to prevent some unit sounds being lost.


1.01 - QuickFix

Fixed a rare bug which corrupted first .XCR entry.

1.0 - First release.

General unit statistics.  Advanced features to be added (ID, Sounds etc)

.XCR support, .ARM support.



**********
Disclaimer
**********

I (Dal Gurak) cannot accept any responsibility for ANY damages caused through the use of this application.  Use this program entirely
at your OWN personal risk.



************
Contact Info
************

Dal Gurak
